# encoding: utf-8
# module PIL._imagingmath
# from /usr/local/lib/python3.7/site-packages/PIL/_imagingmath.cpython-37m-x86_64-linux-gnu.so
# by generator 1.145
# no doc
# no imports

# Variables with simple values

abs_F = 139985897827824
abs_I = 139985897825360

add_F = 139985897828560
add_I = 139985897825552

and_I = 139985897826368

diff_F = 139985897829840
diff_I = 139985897826144

div_F = 139985897829712
div_I = 139985897825888

eq_F = 139985897831024
eq_I = 139985897827152

ge_F = 139985897833376
ge_I = 139985897827712

gt_F = 139985897832944
gt_I = 139985897827600

invert_I = 139985897826272

le_F = 139985897832464
le_I = 139985897827488

lshift_I = 139985897826704

lt_F = 139985897831984
lt_I = 139985897827376

max_F = 139985897830640
max_I = 139985897827040

min_F = 139985897830256
min_I = 139985897826928

mod_F = 139985897834064
mod_I = 139985897826016

mul_F = 139985897829328
mul_I = 139985897825776

neg_F = 139985897828192
neg_I = 139985897825456

ne_F = 139985897831488
ne_I = 139985897827264

or_I = 139985897826480

pow_F = 139985897834352
pow_I = 139985897833808

rshift_I = 139985897826816

sub_F = 139985897828944
sub_I = 139985897825664

xor_I = 139985897826592

# functions

def binop(*args, **kwargs): # real signature unknown
    pass

def unop(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is ''

__spec__ = None # (!) real value is ''

