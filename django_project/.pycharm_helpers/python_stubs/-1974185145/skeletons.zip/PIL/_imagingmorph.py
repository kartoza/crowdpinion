# encoding: utf-8
# module PIL._imagingmorph
# from /usr/local/lib/python3.7/site-packages/PIL/_imagingmorph.cpython-37m-x86_64-linux-gnu.so
# by generator 1.145
""" A module for doing image morphology """
# no imports

# Variables with simple values

__version = '0.1'

# functions

def apply(*args, **kwargs): # real signature unknown
    pass

def get_on_pixels(*args, **kwargs): # real signature unknown
    pass

def match(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is ''

__spec__ = None # (!) real value is ''

