# encoding: utf-8
# module _opcode
# from /usr/local/lib/python3.7/lib-dynload/_opcode.cpython-37m-x86_64-linux-gnu.so
# by generator 1.145
""" Opcode support module. """
# no imports

# functions

def stack_effect(*args, **kwargs): # real signature unknown
    """ Compute the stack effect of the opcode. """
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is ''

__spec__ = None # (!) real value is ''

