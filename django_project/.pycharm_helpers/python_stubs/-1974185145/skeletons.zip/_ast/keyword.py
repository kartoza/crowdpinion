# encoding: utf-8
# module _ast
# from /usr/local/lib/python3.7/site-packages/coverage/tracer.cpython-37m-x86_64-linux-gnu.so
# by generator 1.145
# no doc
# no imports

from .AST import AST

class keyword(AST):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    _attributes = ()
    _fields = (
        'arg',
        'value',
    )


