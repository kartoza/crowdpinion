# encoding: utf-8
# module _ast
# from /usr/local/lib/python3.7/site-packages/coverage/tracer.cpython-37m-x86_64-linux-gnu.so
# by generator 1.145
# no doc
# no imports

from .unaryop import unaryop

class Invert(unaryop):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    _fields = ()


