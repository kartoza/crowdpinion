# encoding: utf-8
# module _testimportmultiple
# from /usr/local/lib/python3.7/lib-dynload/_testimportmultiple.cpython-37m-x86_64-linux-gnu.so
# by generator 1.145
""" _testimportmultiple doc """
# no imports

# no functions
# no classes
# variables with complex values

__loader__ = None # (!) real value is ''

__spec__ = None # (!) real value is ''

