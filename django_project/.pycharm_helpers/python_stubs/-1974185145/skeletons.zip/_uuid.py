# encoding: utf-8
# module _uuid
# from /usr/local/lib/python3.7/lib-dynload/_uuid.cpython-37m-x86_64-linux-gnu.so
# by generator 1.145
# no doc
# no imports

# Variables with simple values

has_uuid_generate_time_safe = 1

# functions

def generate_time_safe(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is ''

__spec__ = None # (!) real value is ''

